<?php

namespace App\Http\Controllers;

use App\Models\Tb_visitor;
use Illuminate\Http\Request;

class TbVisitorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tb_visitor  $tb_visitor
     * @return \Illuminate\Http\Response
     */
    public function show(Tb_visitor $tb_visitor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tb_visitor  $tb_visitor
     * @return \Illuminate\Http\Response
     */
    public function edit(Tb_visitor $tb_visitor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tb_visitor  $tb_visitor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tb_visitor $tb_visitor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tb_visitor  $tb_visitor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tb_visitor $tb_visitor)
    {
        //
    }
}

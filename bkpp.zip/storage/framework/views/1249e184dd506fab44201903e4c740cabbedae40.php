<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#galeri').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Forum</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/module">Module</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Kalender Kegiatan</a>
                </li>
            </ul>

        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="card-title"> Tambah Kalender Kegiatan</div>
                    </div>
                    <div class="col">
                    </div>
                    <div class="col">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('kalender-kegiatan.store')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for=""> Nama Kegitan</label>
                        <input type="text" name="nama_kegiatan" required class="form-control"
                            placeholder="Masukan Nama Kegiatan" name="" id="">
                    </div>
                    <div class="form-group">
                        <label for=""> Tanggal Kegiatan</label>
                        <input type="datetime-local" name="waktu_kegiatan" required class="form-control"
                            placeholder="Masukan Nama Kegiatan" name="" id="">
                    </div>
                    <div class="form-group">
                        <label for=""> Deskripsi</label>
                        <textarea name="deskripsi" id="" class="form-control" required cols="30" rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary float-right">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/admin/kalender_kegiatan/create.blade.php ENDPATH**/ ?>
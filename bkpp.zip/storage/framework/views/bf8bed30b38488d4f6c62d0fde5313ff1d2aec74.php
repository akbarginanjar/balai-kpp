<?php $__env->startSection('content'); ?>
    <?php
        use App\Models\Tb_artikel;
        use Illuminate\Support\Carbon;
        $artikel = Tb_artikel::orderBy('created_at', 'desc')->paginate(10);
    ?>
    <style>
        .card-artikel {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            width: 100%;
            border-radius: 13px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-artikel:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .list-tile__title {
            margin: 0;
            font-size: 1.1em;
            color: #333;
            font-weight: bold;
        }

        .list-tile__subtitle {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <br><br>
    <div class="container mb-5">
        <section id="recent-blog-posts" class="recent-blog-posts">

            <div class="container" data-aos="fade-up">
                <h4 class="" style="font-family: 'Nunito', sans-serif; color: #2E4370"><b>Artikel</b>
                </h4>
                <div class="row">
                    <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 mt-3">
                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                <div class="row card-artikel">
                                    <img src="<?php echo e($item->gambar()); ?>"
                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                        alt="Avatar" class="col-2">
                                    <div class="col">
                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <br>
            <center>
                <?php echo $artikel->links(); ?>

            </center>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/member/top-header/artikel.blade.php ENDPATH**/ ?>
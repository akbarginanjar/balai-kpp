<?php
    use App\Models\Tb_video;
    $video = Tb_video::orderBy('created_at', 'desc')->paginate(10);
?>
<div>
    <div class="container">
        <section id="recent-blog-posts" class="recent-blog-posts">
            <div class="" data-aos="fade-up">
                <div class="row">
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="post-box">
                                <div class="post-img"><img
                                        src="https://img.youtube.com/vi/<?php echo e($item->link); ?>/hqdefault.jpg"
                                        class="img-fluid" alt=""></div>
                                
                                <h5 class="post-title"><?php echo e(Str::limit($item->judul, 50)); ?></h5>
                                <a href="/video/<?php echo e($item->slug); ?>" class="readmore stretched-link mt-auto"><span>Lihat
                                        Video</span><i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <br>
            <center>
                <?php echo $video->links(); ?>

            </center>
        </section>
    </div>
</div>
<?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/components/video.blade.php ENDPATH**/ ?>
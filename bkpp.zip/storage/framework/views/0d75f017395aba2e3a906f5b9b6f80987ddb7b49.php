<?php
    use App\Models\Tb_artikel;
    $artikel = Tb_artikel::orderBy('created_at', 'desc')->paginate(10);
?>
<div>
    <style>
        .card-artikel {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            width: 100%;
            border-radius: 13px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-artikel:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .list-tile__title {
            margin: 0;
            font-size: 1.1em;
            color: #333;
            font-weight: bold;
        }

        .list-tile__subtitle {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <div class="container">
        <section id="recent-blog-posts" class="recent-blog-posts">

            <div class="" data-aos="fade-up">
                
                <div class="row">
                    <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 mt-3">
                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                <div class="row card-artikel">
                                    <img src="<?php echo e($item->gambar()); ?>"
                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                        alt="Avatar" class="col-2">
                                    <div class="col">
                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <br>
            <center>
                <?php echo $artikel->links(); ?>

            </center>
        </section>
    </div>
</div>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/components/artikel.blade.php ENDPATH**/ ?>
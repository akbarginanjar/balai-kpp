<?php
    use App\Models\Tb_menu;
    use App\Models\Tb_submenu;
    use App\Models\Tb_setting;
    use App\Models\Tb_visitor;
    $visitors = Tb_visitor::count();
    $setting = Tb_setting::find(1);
    $menu = Tb_menu::orderBy('urutan', 'asc')->get();
?>

<!-- ======= Footer ======= -->
<footer id="footer" class="footer">

    <div class="footer-newsletter">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <h4>Berlangganan</h4>
                    <p>Silahkan masukan Email anda untuk Berlangganan</p>
                </div>
                <div class="col-lg-6">

                    <form action="/subscribe" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="email" name="email" required>
                        <input type="button" value="Subscribe" style="background: rgba(46,67,112,1);"
                            data-bs-toggle="modal" data-bs-target="#subscribe">
                        
                        <div class="modal fade" id="subscribe" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Masukan Chaptcha dengan benar
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group mt-2" style="font-size: 14px;">
                                            <label for="captcha" class="mb-1">Captcha</label>
                                            <div>
                                                <img src="<?php echo e(captcha_src()); ?>" alt="captcha" class="captcha-img"
                                                    data-refresh-config="default">
                                                <a href="javascript:void(0)" class="refresh-captcha ms-2">Refresh</a>
                                            </div>
                                            <input type="text" id="captcha" name="captcha"
                                                class="form-control mt-2" style="width: 200px;" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn"
                                            style="background: rgba(46,67,112,1); color: white;">Subscribe</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-top">
        <div class="container">
            <div class="row gy-4">
                <div class="col-sm footer-info">
                    <a href="/" class="logo d-flex align-items-center">
                        
                        <span><?php echo e($setting->judul); ?></span>
                    </a>
                    <p><?php echo e($setting->alamat); ?></p>
                    <div class="social-links mt-3">
                        <a href="<?php echo e($setting->facebook); ?>" class="facebook"><i class="bi bi-facebook"></i></a>
                        <a href="<?php echo e($setting->instagram); ?>" class="instagram"><i class="bi bi-instagram"></i></a>
                        <a href="<?php echo e($setting->twitter); ?>" class="tiktok"><i class="bi bi-tiktok"></i></a>
                        
                    </div>
                </div>

                <div class="col-sm footer-links">
                    <h4>Menu</h4>
                    <ul>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id_konten === 0): ?>
                                <li class="nav-item dropdown">
                                    <i class="bi bi-chevron-right"></i>
                                    <a id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false" v-pre style="text-decoration: none;">
                                        <?php echo e($item->nama); ?>

                                    </a>

                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <?php
                                            $submenu = Tb_submenu::where('id_menu', $item->id)->get();
                                        ?>
                                        <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/s=><?php echo e($data->slug); ?>"
                                                class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($data->nama); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                            <?php else: ?>
                                <li><i class="bi bi-chevron-right"></i> <a
                                        href="/m=><?php echo e($item->slug); ?>"><?php echo e($item->nama); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                

                <div class="col-sm footer-contact text-center text-md-start">
                    <h4>Kontak Kami</h4>
                    
                    <strong>Phone:</strong> <?php echo e($setting->call_us); ?><br>
                    <strong>Email:</strong> <?php echo e($setting->email_us); ?><br>
                    </p>
                    <div class="card border-0 shadow" style="border-radius: 13px;">
                        <div class="card-body">
                            <h5>Visitor: <b> <?php echo e(number_format($visitors, 0, ',', '.')); ?> </b></h5>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span><?php echo e($setting->judul); ?></span></strong>. All Rights Reserved
        </div>
        
    </div>
</footer><!-- End Footer -->

<script type="text/javascript">
    document.querySelector('.refresh-captcha').addEventListener('click', function() {
        var captchaImage = document.querySelector('.captcha-img');
        var captchaSrc = captchaImage.src.split('?')[0];
        captchaImage.src = captchaSrc + '?' + Math.random();
    });
</script>

<!-- Footer Start -->

<!-- Footer End -->
<?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/layouts/partials/member/footer.blade.php ENDPATH**/ ?>
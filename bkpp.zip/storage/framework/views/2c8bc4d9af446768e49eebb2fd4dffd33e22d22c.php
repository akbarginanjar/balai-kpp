<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
        integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
        crossorigin="" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css" />

    <style>
        #mapid {
            min-height: 500px;
        }

        table tr th {
            text-align: center;
        }

        td {
            text-align: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
        integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
        crossorigin=""></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js"></script>

    <script>
        var map = L.map('mapid').setView([<?php echo e(config('leaflet.map_center_latitude')); ?>,
            <?php echo e(config('leaflet.map_center_longitude')); ?>

        ], <?php echo e(config('leaflet.zoom_level')); ?>);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        var markers = L.markerClusterGroup();

        axios.get('<?php echo e(route('api.peta.index')); ?>')
            .then(function(response) {
                var marker = L.geoJSON(response.data, {
                    pointToLayer: function(geoJsonPoint, latlng) {
                        return L.marker(latlng).bindPopup(function(layer) {
                            return layer.feature.properties.map_popup_content;
                        });
                    }
                });
                markers.addLayer(marker);
            })
            .catch(function(error) {
                console.log(error);
            });
        map.addLayer(markers);

        var theMarker;
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        use App\Models\Tb_kategori_konten;
        use App\Models\Tb_artikel;
        use Illuminate\Support\Carbon;
    ?>
    <style>
        .card-artikel {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            width: 100%;
            border-radius: 13px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-artikel:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .list-tile__title {
            margin: 0;
            font-size: 1.1em;
            color: #333;
            font-weight: bold;
        }

        .list-tile__subtitle {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #666;
        }
    </style>
    <br><br><br>
    <div class="container mt-5" style="margin-top: 120px;">
        <?php if($submenu->konten->halaman != ''): ?>
            <?php if($submenu->konten->halaman->judul): ?>
                <header class="section-header">
                    <p class="mt-4 text-uppercase"><?php echo e($submenu->konten->halaman->judul); ?></p>
                </header>
            <?php endif; ?>
            
            <div class="row">
                <?php if($submenu->konten->halaman->atas_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->atas_tengah);
                ?>
                <?php if($submenu->konten->halaman->atas_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.video','data' => []]); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->atas_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.ebook','data' => []]); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->atas_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>

                        
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->atas_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->atas_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if($submenu->konten->halaman->gambar != null): ?>
                <img class="rounded"
                    src="<?php echo e($submenu->konten->halaman ? $submenu->konten->halaman->gambar() : 'no_image'); ?>" alt="Gambar">
            <?php endif; ?>

            <?php if($submenu->konten->halaman->teks): ?>
                <div class="card border-0">
                    <?php echo $submenu->konten->halaman->teks; ?>

                </div>
            <?php endif; ?>
            
            <div class="row">
                <?php if($submenu->konten->halaman->tengah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->tengah);
                ?>
                <?php if($submenu->konten->halaman->tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.video','data' => []]); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.ebook','data' => []]); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->tengah == 'Kalender'): ?>
                    <div class="col">
                        <style>
                            td {
                                font-weight: 400;
                                font-size: 14px;
                            }

                            .select-date {
                                background: rgb(255, 191, 0);
                                border-radius: 30px;
                                text-align: center;
                                padding: 10px;
                                font-weight: bold;
                            }

                            .sudah-terlaksana {
                                border-radius: 5px;
                                color: white;
                                background: rgb(18, 44, 147);
                                padding: 10px;
                            }
                        </style>
                        <section id="recent-blog-posts" class="recent-blog-posts">
                            <div class="" data-aos="fade-up">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="row">
                                            <div class="col-sm">
                                                <h3 class="mt-3"><b>2023</b></h3>
                                            </div>
                                            <div class="col-sm-3">
                                                <div style="font-size: 12px;">Pilih Tahun</div>
                                                <select name="" class="form-control form-control-sm">
                                                    <option value="2022">2022</option>
                                                    <option value="2023" selected>2023</option>
                                                    <option value="2024">2024</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2" class="text-center">Nama Kegiatan</th>
                                                    <th colspan="12" class="text-center">Pelaksanaan</th>
                                                    <th rowspan="2" class="text-center">Tanggal</th>
                                                    <th rowspan="2" class="text-center">Waktu</th>
                                                    <th rowspan="2" class="text-center">Status</th>
                                                </tr>
                                                <tr>
                                                    <th>Jan</th>
                                                    <th>Feb</th>
                                                    <th>Mar</th>
                                                    <th>Apr</th>
                                                    <th>Mei</th>
                                                    <th>Jun</th>
                                                    <th>Jul</th>
                                                    <th>Ags</th>
                                                    <th>Sep</th>
                                                    <th>Okt</th>
                                                    <th>Nov</th>
                                                    <th>Des</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Pengujian Lapangan Keandalan Bangunan Gedung Aspek Sains Bangunan
                                                    </td>
                                                    <td></td>
                                                    <td>
                                                        <div class="select-date">25</div>
                                                    </td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>25/Feb/2023</td>
                                                    <td>09:00</td>
                                                    <td>
                                                        <div class="sudah-terlaksana">Sudah Terlaksana</div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>otential of Wooden Affordable Apartments Towards Zero-carbon Society
                                                    </td>
                                                    <td></td>
                                                    <td>

                                                    </td>
                                                    <td>
                                                        <div class="select-date">15</div>
                                                    </td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td>15/Mar/2023</td>
                                                    <td>10:00</td>
                                                    <td>
                                                        <div class="sudah-terlaksana">Sudah Terlaksana</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>

                        
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->tengah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->tengah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            
            <div class="row">
                <?php if($submenu->konten->halaman->bawah_kiri == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_kiri == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php
                    $kategoriKonten = Tb_kategori_konten::find($submenu->konten->halaman->bawah_tengah);
                ?>
                <?php if($submenu->konten->halaman->bawah_tengah == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Video'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.video','data' => []]); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif($submenu->konten->halaman->bawah_tengah == 'Ebook'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.ebook','data' => []]); ?>
<?php $component->withName('ebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php elseif(isset($kategoriKonten)): ?>
                    <div class="col">
                        <?php
                            $konten = Tb_artikel::where('id_kategori_konten', $submenu->konten->halaman->bawah_tengah)
                                ->orderBy('created_at', 'desc')
                                ->paginate(9);
                        ?>
                        <div class="" data-aos="fade-up">
                            <div class="" data-aos="fade-up">
                                <div class="row">
                                    <?php $__currentLoopData = $konten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 mt-3">
                                            <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                                <div class="row card-artikel">
                                                    <img src="<?php echo e($item->gambar()); ?>"
                                                        style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                                        alt="Avatar" class="col-2">
                                                    <div class="col">
                                                        <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                                        <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <center>
                            <?php echo $konten->links(); ?>

                        </center>

                        
                    </div>
                <?php endif; ?>
                <?php if($submenu->konten->halaman->bawah_kanan == 'Slide'): ?>
                    <!-- Carousel Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slide::class, []); ?>
<?php $component->withName('slide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e)): ?>
<?php $component = $__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e; ?>
<?php unset($__componentOriginal8c53640370bfbe840d44e104a6d7ec390cdec79e); ?>
<?php endif; ?>
                    </div>
                    <!-- Carousel End -->
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Galeri'): ?>
                    <!-- Galeri Start -->
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Galeri::class, []); ?>
<?php $component->withName('galeri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda)): ?>
<?php $component = $__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda; ?>
<?php unset($__componentOriginalb1e2c97b8446465f8c1012f1051b34eb36b40cda); ?>
<?php endif; ?>
                    </div>
                    <!-- Galeri End -->
                <?php elseif($submenu->konten->halaman->bawah_kanan == 'Kontak'): ?>
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.kontak','data' => []]); ?>
<?php $component->withName('kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
        <?php elseif($submenu->konten->artikel != ''): ?>
            <?php if($submenu->konten->artikel->gambar != null): ?>
                <img class="rounded"
                    src="<?php echo e($submenu->konten->artikel ? $submenu->konten->artikel->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->artikel->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->artikel->teks; ?>

            </div>
        <?php elseif($submenu->konten->kategoriArtikel != ''): ?>
            <?php
                // use App\Models\Tb_kategori_artikel;
                $artikel = Tb_artikel::where('id_kategori_artikel', $submenu->konten->kategoriArtikel->id)
                    ->orderBy('created_at', 'desc')
                    ->paginate(8);
            ?>
            <h5 class="mt-4"><b> Kategori <?php echo e($submenu->konten->kategoriArtikel->nama); ?></b></h5>
            <div class="" data-aos="fade-up">
                <div class="" data-aos="fade-up">
                    <div class="row">
                        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 mt-3">
                                <a href="/artikel/<?php echo e($item->kategoriArtikel->slug); ?>/<?php echo e($item->slug); ?>">
                                    <div class="row card-artikel">
                                        <img src="<?php echo e($item->gambar()); ?>"
                                            style="object-fit: cover; height: 100px; width: 150px; border-radius: 13px;"
                                            alt="Avatar" class="col-2">
                                        <div class="col">
                                            <h3 class="list-tile__title"><?php echo Str::limit($item->judul, 60); ?></h3>
                                            <span class="list-tile__subtitle"><?php echo Str::limit($item->teks, 70); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <center>
                <?php echo $artikel->links(); ?>

            </center>
        <?php elseif($submenu->konten->kegiatan != ''): ?>
            <?php if($submenu->konten->kegiatan->gambar != null): ?>
                <img class="rounded"
                    src="<?php echo e($submenu->konten->kegiatan ? $submenu->konten->kegiatan->gambar() : 'no_image'); ?>"
                    alt="Gambar">
            <?php endif; ?>
            <h1 class="mt-4 text-uppercase"><?php echo e($submenu->konten->kegiatan->judul); ?></h1>
            <div class="card border-0">
                <?php echo $submenu->konten->kegiatan->teks; ?>

            </div>
        <?php else: ?>
            <br><br><br>
            <center>Tidak Ada Konten</center>
            <br><br>
            <br>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/member/submenu.blade.php ENDPATH**/ ?>
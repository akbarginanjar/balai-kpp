<!DOCTYPE html>
<html>

<head>
    <title>Post to Instagram</title>
</head>

<body>
    <h1>Post to Instagram</h1>
    <form action="<?php echo e(route('instagram.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="image">Image:</label>
            <input type="file" id="image" name="image" required>
        </div>
        <div>
            <label for="caption">Caption:</label>
            <textarea id="caption" name="caption" rows="4" required></textarea>
        </div>
        <div>
            <button type="submit">Post to Instagram</button>
        </div>
    </form>
</body>

</html>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/instagram-post.blade.php ENDPATH**/ ?>
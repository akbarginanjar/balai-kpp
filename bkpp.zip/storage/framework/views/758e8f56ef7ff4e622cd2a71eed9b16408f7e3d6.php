

<?php $__env->startSection('content'); ?>
    <br><br><br>
    <center>
        <div class="container mt-5">
            <div class="mt-5 ">
                <button class="btn btn-primary border-0" data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                    style="background: rgb(247, 161, 2)">Apa yang Anda Pikirkan
                    ?</button>
            </div>
        </div>
    </center>

    <div class="container mt-5">
        <?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($iem->publish == 1): ?>
                <div class="card border-0 " style="box-shadow: 0px 3px 10px rgb(231, 231, 231) ">
                    <div class="card-body">
                        <b><?php echo e($item->name); ?></b>
                        <h6 class="mt-2"><?php echo e($item->email); ?></h6>
                        <div class="alert alert-secondary" role="alert">
                            <?php echo e($item->comment); ?>

                        </div>
                        <div class="d-flex gap-2 ml-auto">
                            <a href="" class="btn btn-danger">Hapus</a>
                            <a href="" class="btn text-white" style="background: rgb(247, 161, 2)">Balas</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>





    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form action="/comment-post" method="post" class="mt-3" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="modal-header">
                            <h6><b>pa yang anda pikirkan??</b></h6>
                        </div>
                        <div class="container">
                            <div class="form-group">
                                <label for=""><b>Username</b></label>
                                <input required type="text" placeholder="username" name="name"
                                    class="form-control mt-2">
                            </div>
                            <div class="form-group mt-3">
                                <label for=""><b>email</b></label>
                                <input required type="email" placeholder="email" name="email" class="form-control mt-2">
                            </div>
                            <div class="form-group mt-3">
                                <label for=""><b>comment</b></label>
                                <textarea required placeholder="comment" name="comment" class="form-control mt-2"> </textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary border-0"
                            style="background: rgb(247, 161, 2)">send</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/forum.blade.php ENDPATH**/ ?>
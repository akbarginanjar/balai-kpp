<!-- Sidebar -->
<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            
            <ul class="nav nav-primary">
                <li class="nav-item <?php echo e(Request::is('master-admin/dashboard') ? 'active' : ''); ?>">
                    <a href="/master-admin/dashboard" class="collapsed"> <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php if(Auth::user()->id == 1): ?>
                    <li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                        <a href="/" class="collapsed" target="_blank"> <i class="fa-solid fa-eye"></i></i>
                            <p>Preview</p>
                        </a>
                    </li>
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">Menu</h4>
                    </li>

                    <li class="nav-item <?php echo e(Request::is('master-admin/menu') ? 'active' : ''); ?>">
                        <a href="/master-admin/menu">
                            <i class="fa-solid fa-bars-staggered"></i>
                            <p>Menu</p>
                        </a>
                    </li>
                    
                    
                    <li class="nav-item <?php echo e(Request::is('master-admin/halaman') ? 'active' : ''); ?>">
                        <a href="/master-admin/halaman">
                            <i class="fa-solid fa-layer-group"></i>
                            <p>Halaman</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(Request::is('master-admin/link') ? 'active' : ''); ?>">
                        <a href="/master-admin/link">
                            <i class="fa-solid fa-link"></i>
                            <p>Link</p>
                        </a>
                    </li>
                    
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">Pengaturan</h4>
                    </li>
                    <li class="nav-item <?php echo e(Request::is('master-admin/module') ? 'active' : ''); ?>">
                        <a href="/master-admin/module">
                            <i class="fa-solid fa-list"></i>
                            <p>Module</p>
                        </a>
                    </li>
                    <li class="nav-item <?php echo e(Request::is('master-admin/setting') ? 'active' : ''); ?>">
                        <a href="/master-admin/setting">
                            <i class="fa-solid fa-gears"></i>
                            <p>Settings</p>
                        </a>
                    </li>
                    
                    
                    
                    
                    <li class="nav-section">
                        <span class="sidebar-mini-icon">
                            <i class="fa fa-ellipsis-h"></i>
                        </span>
                        <h4 class="text-section">User</h4>
                    </li>
                    
                    <li class="nav-item <?php echo e(Request::is('master-admin/pengguna') ? 'active' : ''); ?>">
                        <a href="/master-admin/pengguna">
                            <i class="fa-solid fa-users"></i>
                            <p>Pengguna</p>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item <?php echo e(Request::is('master-admin/artikel') ? 'active' : ''); ?>">
                        <a href="/master-admin/artikel">
                            <i class="fa-solid fa-newspaper"></i>
                            <p>Artikel</p>
                        </a>
                    </li>
                <?php endif; ?>
                

                










                
            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->
<?php /**PATH C:\xampp\htdocs\LARAVEL\balai-kpp-master\resources\views/layouts/partials/admin/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Illuminate\Support\Carbon;
        use App\Models\Tb_artikel;
        use App\Models\Tb_comment;
        $countKomentar = Tb_comment::count();
    ?>
    
    <br> <br> <br>
    <section id="blog" class="blog">
        <div class="container" data-aos="fade-up">

            <div class="row">

                <div class="col-lg-8 entries">

                    <article class="entry entry-single">

                        <div class="entry-img">
                            <img src="<?php echo e($artikel->gambar()); ?>" alt="" class="rounded   "
                                style="width: 100%; object-fit: cover">
                        </div>

                        <h2 class="entry-title">
                            <a href=""><?php echo e($artikel->judul); ?></a>
                        </h2>

                        <div class="entry-meta">
                            <ul>
                                <li class="d-flex align-items-center"><i class="bi bi-person"></i><?php echo e($artikel->user->name); ?>

                                </li>
                                <li class="d-flex align-items-center"><i class="bi bi-calendar"></i><time
                                        datetime="2020-01-01"><?php echo e(Carbon::parse($artikel->tgl_pembuatan)->translatedFormat('D, d F Y')); ?></time></a>
                                </li>
                                <li class="d-flex align-items-center"><i
                                        class="bi bi-clock"></i><time><?php echo e($artikel->waktu_pembuatan); ?></time></a>
                                </li>
                                <li class="d-flex align-items-center"><i class="bi bi-eye"></i><time><?php echo e($artikel->viewer); ?>

                                        Viewer</time></a>
                                </li>
                            </ul>
                        </div>
                        <div class="row">
                            <div class="col">
                                <h6><b>Share</b></h6>
                                <a href="https://api.whatsapp.com/send?text=<?php echo e($url); ?>" class="btn"
                                    style="background: rgb(13, 187, 13);" target="_blank">
                                    <i class="bi bi-whatsapp text-white" style="font-size: 18px;"></i>
                                </a>
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>" target="_blank"
                                    class="btn" style="background: rgb(83, 83, 175);">
                                    <i class="bi bi-facebook text-white" style="font-size: 18px;"></i>
                                </a>
                                <a class="btn" onclick="copyUrlInstagram()" style="background: rgb(221, 39, 185);">
                                    <i class="bi bi-instagram text-white" style="font-size: 18px;"></i>
                                </a>
                            </div>
                        </div>
                        <!-- Input untuk URL artikel -->
                        <input type="text" id="articleUrl" value="<?php echo e($url); ?>" hidden>

                        <script>
                            function copyUrlInstagram() {
                                var copyText = document.getElementById("articleUrl");
                                copyText.select();
                                copyText.setSelectionRange(0, 99999); // For mobile devices
                                document.execCommand("copy");
                                alert("Link berhasil disalin: " + copyText.value);
                            }
                        </script>

                        <div class="entry-content mt-3">

                            <?php echo $artikel->teks; ?>

                        </div>

                    </article><!-- End blog entry -->
                </div><!-- End blog entries list -->

                <div class="col-lg-4">

                    <div class="sidebar">
                        <h3 class="sidebar-title">Kategori</h3>
                        <div class="sidebar-item categories">
                            <ul>
                                <?php $__currentLoopData = $kategoriArtikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $artikela = Tb_artikel::where('id_kategori_artikel', $item->id)->get();
                                        $no = $artikela->count();
                                    ?>
                                    <li><a
                                            href="/artikel/<?php echo e($item->slug); ?>"><?php echo e($item->nama); ?><span>(<?php echo e($no); ?>)</span></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><!-- End sidebar categories-->

                        <h3 class="sidebar-title">Artikel Terkait</h3>
                        <div class="sidebar-item recent-posts">
                            <?php
                                $artikell = Tb_artikel::where('id_kategori_artikel', $artikel->id_kategori_artikel)
                                    ->inRandomOrder()
                                    ->limit(6)
                                    ->get();
                            ?>
                            <?php $__currentLoopData = $artikell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->id != $artikel->id): ?>
                                    <div class="post-item clearfix">
                                        <img src="<?php echo e($data->gambar()); ?>" alt="">
                                        <h4><a
                                                href="/artikel/<?php echo e($data->kategoriArtikel->slug); ?>/<?php echo e($data->slug); ?>"><?php echo e($data->judul); ?></a>
                                        </h4>
                                        <time
                                            datetime="2020-01-01"><?php echo e(Carbon::parse($data->created_at)->translatedFormat('D, d F Y')); ?></time>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div><!-- End sidebar recent posts-->


                    </div><!-- End sidebar -->

                </div><!-- End blog sidebar -->

            </div>

            <div class="col-sm-8">
                <hr>
                <h5><b> Komentar </b></h5>

                <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($comment->publish == 1): ?>
                        <div class="">
                            <div class="p-3">
                                <b> <?php echo e($comment->name); ?> </b><br>
                                <div class="text-secondary" style="font-size: 12px;">
                                    <?php echo e(Carbon::parse($comment->created_at)->translatedFormat('D, d F Y')); ?></div>
                                <span class="mt-1" style="font-size: 15px;"><?php echo e($comment->teks); ?></span>
                                <?php if($comment->reply != null): ?>
                                    <div class="ms-4 mt-2">
                                        <div style="color: rgba(46,67,112,1); font-size: 12px;"><i
                                                class="bi bi-arrow-return-right"></i> Dibalas oleh Admin</div>
                                        <div style="font-size: 15px;" class="ms-3"><?php echo e($comment->reply); ?></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="background: rgb(206, 206, 206); height: 1px;"></div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <b>Leave a reply:</b>
                <div style="font-size: 13;">Your email address will not be published.</div>
                <form action="/artikel/<?php echo e($artikel->kategoriArtikel->slug); ?>/<?php echo e($artikel->slug); ?>/sendComment"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_artikel" value="<?php echo e($artikel->id); ?>">
                    <div class="form-group">
                        <label style="font-size: 14px;" class="mt-2">Name</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="form-group">
                        <label style="font-size: 14px;" class="mt-2">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div>
                        <label style="font-size: 14px;" class="mt-2">Komentar</label>
                        <textarea class="form-control" rows="3" name="teks" required></textarea>
                    </div>
                    <div class="form-group mt-2" style="font-size: 14px;">
                        <label for="captcha">Captcha</label>
                        <div>
                            <img src="<?php echo e(captcha_src()); ?>" alt="captcha" class="captcha-img"
                                data-refresh-config="default">
                            <a href="javascript:void(0)" class="refresh-captcha ms-2">Refresh</a>
                        </div>
                        <input type="text" id="captcha" name="captcha" class="form-control mt-2"
                            style="width: 200px;" required>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3" style="background: navy;">Post Comment</button>
                </form>
            </div>

        </div>

    </section>
    <div class="container">
        <section id="recent-blog-posts" class="recent-blog-posts">
            <div class="container" data-aos="fade-up">
                <header class="section-header">
                    <p>Rekomendasi untuk anda</p>
                </header>
                <div class="row">
                    <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($data->id != $artikel->id): ?>
                            <div class="col-lg-3 mt-3">
                                <div class="post-box">
                                    <div class="post-img"><img src="<?php echo e($data->gambar()); ?>" class=""
                                            style="width: 100%; height:160px; object-fit:cover;" alt="">
                                    </div>
                                    <h5 class="post-title"><?php echo e($data->judul); ?></h5>
                                    <a href="/artikel/<?php echo e($data->kategoriArtikel->slug); ?>/<?php echo e($data->slug); ?>"
                                        class="readmore stretched-link"></a>
                                    <span class="mt-auto" style="font-size: 10px; float:bottom;"><i
                                            class="bi bi-person me-1"></i>
                                        <?php echo e($data->user->name); ?>

                                        <span class="" style="float: right">
                                            <i class="bi bi-clock me-1"></i><time
                                                datetime="2020-01-01"><?php echo e(Carbon::parse($data->created_at)->translatedFormat('d M Y')); ?></time></span>
                                    </span>
                                    </span>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>

    <script type="text/javascript">
        document.querySelector('.refresh-captcha').addEventListener('click', function() {
            var captchaImage = document.querySelector('.captcha-img');
            var captchaSrc = captchaImage.src.split('?')[0];
            captchaImage.src = captchaSrc + '?' + Math.random();
        });
    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL\balai-kpp-master\resources\views/member/artikel-detail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('ckeditor'); ?>
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace('ckeditor', {
            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/js/jquery.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/select2.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>

    <script>
        $(".theSelect").select2();
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Halaman</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/halaman">Halaman</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Edit Halaman</a>
                </li>
            </ul>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title col-sm-10">Edit Data Halaman</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('halaman.update', $halaman->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label>Judul</label>
                        <div class="input-group ">
                            <input type="text" value="<?php echo e($halaman->judul); ?>" placeholder="Masukkan Judul halaman"
                                name="judul" autocomplete='off' class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Teks</label>
                        <textarea name="teks" id="ckeditor" autocomplete='off' class="form-control <?php $__errorArgs = ['teks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            cols="30" rows="8"><?php echo e($halaman->teks); ?></textarea>
                        <?php $__errorArgs = ['teks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label>Upload File Gambar</label>
                        <div class="custom-file mb-3">
                            <input type="file" id="file" name="gambar"
                                class="custom-file-input <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*"
                                onchange="tampilkanPreview(this,'preview')" id="customFile">
                            <label class="custom-file-label" for="customFile">Choose
                                file</label>
                        </div>
                        <div class="row">
                            <div class="col">
                                <img src="<?php echo e($halaman->gambar()); ?>" class="rounded img-fluid" alt="">
                            </div>
                            <div class="col">
                                <center>
                                    <span id="panah"></span>
                                </center>
                            </div>
                            <div class="col">
                                <img id="preview" src="" alt="" class="rounded img-fluid float-right" />
                            </div>
                        </div>
                        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group row">
                        <div class="form-group col">
                            <label>Atas Kiri</label>
                            <div class="input-group ">

                                <select name="atas_kiri" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['atas_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->atas_kiri == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->atas_kiri == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->atas_kiri == 'Galeri' ? 'selected' : ''); ?>>Galeri
                                    </option>
                                    <option value="Kontak" <?php echo e($halaman->atas_kiri == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    

                                </select>
                                <?php $__errorArgs = ['atas_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Atas Tengah</label>
                            <div class="input-group ">

                                <select name="atas_tengah" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['atas_tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->atas_tengah == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->atas_tengah == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->atas_tengah == 'Galeri' ? 'selected' : ''); ?>>Galeri
                                    </option>
                                    <option value="Kalender" <?php echo e($halaman->atas_tengah == 'Kalender' ? 'selected' : ''); ?>>
                                        Kalender
                                    </option>
                                    <option value="Kontak" <?php echo e($halaman->atas_tengah == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    <?php $__currentLoopData = $kategoriKontenEbook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKontenEbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKontenEbook->id); ?>,ebook"
                                            <?php echo e($halaman->atas_tengah == $dataKategoriKontenEbook->id . ',ebook' ? 'selected' : ''); ?>>
                                            E-book | <?php echo e($dataKategoriKontenEbook->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $kategoriKonten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKonten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKonten->id); ?>,konten"
                                            <?php echo e($halaman->atas_tengah == $dataKategoriKonten->id . ',konten' ? 'selected' : ''); ?>>
                                            Konten | <?php echo e($dataKategoriKonten->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                </select>
                                <?php $__errorArgs = ['atas_tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Atas Kanan</label>
                            <div class="input-group ">

                                <select name="atas_kanan" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['atas_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->atas_kanan == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->atas_kanan == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->atas_kanan == 'Galeri' ? 'selected' : ''); ?>>Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->atas_kanan == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    <option value="Kalender Widget"
                                        <?php echo e($halaman->atas_kanan == 'Kalender Widget' ? 'selected' : ''); ?>>
                                        Kalender Widget
                                    </option>
                                    

                                </select>
                                <?php $__errorArgs = ['atas_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-group row">
                        <div class="form-group col">
                            <label>Tengah Kiri</label>
                            <div class="input-group ">

                                <select name="tengah_kiri" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['tengah_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->tengah_kiri == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->tengah_kiri == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->tengah_kiri == 'Galeri' ? 'selected' : ''); ?>>
                                        Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->tengah_kiri == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    
                                </select>
                                <?php $__errorArgs = ['tengah_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Tengah</label>
                            <div class="input-group ">

                                <select name="tengah" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->tengah == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->tengah == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->tengah == 'Galeri' ? 'selected' : ''); ?>>Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->tengah == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    <?php $__currentLoopData = $kategoriKontenEbook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKontenEbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKontenEbook->id); ?>,ebook"
                                            <?php echo e($halaman->tengah == $dataKategoriKontenEbook->id . ',ebook' ? 'selected' : ''); ?>>
                                            E-book | <?php echo e($dataKategoriKontenEbook->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $kategoriKonten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKonten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKonten->id); ?>,konten"
                                            <?php echo e($halaman->tengah == $dataKategoriKonten->id . ',konten' ? 'selected' : ''); ?>>
                                            Konten | <?php echo e($dataKategoriKonten->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="Kalender" <?php echo e($halaman->tengah == 'Kalender' ? 'selected' : ''); ?>>
                                        Kalender
                                    </option>
                                    

                                </select>
                                <?php $__errorArgs = ['tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Tengah Kanan</label>
                            <div class="input-group ">

                                <select name="tengah_kanan" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['tengah_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->tengah_kanan == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->tengah_kanan == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->tengah_kanan == 'Galeri' ? 'selected' : ''); ?>>
                                        Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->tengah_kanan == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    

                                </select>
                                <?php $__errorArgs = ['tengah_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-group row">
                        <div class="form-group col">
                            <label>Bawah Kiri</label>
                            <div class="input-group ">

                                <select name="bawah_kiri" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['bawah_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->bawah_kiri == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->bawah_kiri == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->bawah_kiri == 'Galeri' ? 'selected' : ''); ?>>
                                        Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->bawah_kiri == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>

                                    
                                </select>
                                <?php $__errorArgs = ['bawah_kiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Bawah Tengah</label>
                            <div class="input-group ">

                                <select name="bawah_tengah" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['bawah_tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->bawah_tengah == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->bawah_tengah == 'Slide' ? 'selected' : ''); ?>>
                                        Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->bawah_tengah == 'Galeri' ? 'selected' : ''); ?>>
                                        Galeri
                                    </option>
                                    <option value="Kalender" <?php echo e($halaman->bawah_tengah == 'Kalender' ? 'selected' : ''); ?>>
                                        Kalender
                                    </option>
                                    <option value="Kontak" <?php echo e($halaman->bawah_tengah == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    <?php $__currentLoopData = $kategoriKontenEbook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKontenEbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKontenEbook->id); ?>,ebook"
                                            <?php echo e($halaman->bawah_tengah == $dataKategoriKontenEbook->id . ',ebook' ? 'selected' : ''); ?>>
                                            E-book | <?php echo e($dataKategoriKontenEbook->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $kategoriKonten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriKonten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dataKategoriKonten->id); ?>,konten"
                                            <?php echo e($halaman->bawah_tengah == $dataKategoriKonten->id . ',konten' ? 'selected' : ''); ?>>
                                            Konten | <?php echo e($dataKategoriKonten->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                </select>
                                <?php $__errorArgs = ['bawah_tengah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col">
                            <label>Bawah Kanan</label>
                            <div class="input-group ">

                                <select name="bawah_kanan" required
                                    class="form-control form-control
                                theSelect"
                                    <?php $__errorArgs = ['bawah_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                    <option value="Tidak" <?php echo e($halaman->bawah_kanan == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        Ditampilkan</option>
                                    <option value="Slide" <?php echo e($halaman->bawah_kanan == 'Slide' ? 'selected' : ''); ?>>Slide
                                    </option>
                                    <option value="Galeri" <?php echo e($halaman->bawah_kanan == 'Galeri' ? 'selected' : ''); ?>>
                                        Galeri
                                    </option>

                                    <option value="Kontak" <?php echo e($halaman->bawah_kanan == 'Kontak' ? 'selected' : ''); ?>>
                                        Kontak
                                    </option>
                                    

                                </select>
                                <?php $__errorArgs = ['bawah_kanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-warning text-white"><i class="fa fa-save mr-1"></i>
                            Simpan Perubahan</button>
                    </div>
            </div>
        </div>
    </div>


    <script>
        // Add the following code if you want the name of the file appear on select
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    </script>

    <script>
        function tampilkanPreview(gambar, idpreview) {
            var gb = gambar.files;
            for (var i = 0; i < gb.length; i++) {
                var gbPreview = gb[i];
                var imageType = /image.*/;
                var preview = document.getElementById(idpreview);
                var reader = new FileReader();

                if (gbPreview.type.match(imageType)) {
                    preview.file = gbPreview;
                    reader.onload = (function(element) {
                        return function(e) {
                            element.src = e.target.result;
                        };
                    })(preview);
                    document.getElementById("panah").innerHTML =
                        "<br><img src='<?php echo e(asset('images/arrow.png')); ?>' width='90'>";
                    reader.readAsDataURL(gbPreview);
                } else {
                    alert("file yang anda upload tidak sesuai. Khusus mengunakan image.");
                }

            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/admin/halaman/edit.blade.php ENDPATH**/ ?>
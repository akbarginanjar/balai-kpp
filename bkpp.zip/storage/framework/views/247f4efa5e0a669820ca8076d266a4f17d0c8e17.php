<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                
            </ul>
        </nav>
        <div class="copyright ml-auto">
            <?php echo e(date('Y')); ?>

        </div>
    </div>
</footer>
<?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/layouts/partials/admin/footer.blade.php ENDPATH**/ ?>
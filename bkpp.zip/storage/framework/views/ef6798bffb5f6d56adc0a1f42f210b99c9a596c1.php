<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                
            </ul>
        </nav>
        <div class="copyright ml-auto">
            <?php echo e(date('Y')); ?>

        </div>
    </div>
</footer>
<?php /**PATH /home/ayogo/bkpp.ayogo.id/resources/views/layouts/partials/admin/footer.blade.php ENDPATH**/ ?>
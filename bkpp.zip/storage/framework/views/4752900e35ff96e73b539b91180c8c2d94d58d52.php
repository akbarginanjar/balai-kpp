<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#galeri').DataTable();
        });
    </script>
    <script src="<?php echo e(asset('js/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Forum</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="/master-admin/dashboard">
                        <i class="fa-solid fa-house-chimney"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="/master-admin/module">Module</a>
                </li>
                <li class="separator">
                    <i class="fa-solid fa-chevron-right"></i>
                </li>
                <li class="nav-item">
                    <a href="">Forum</a>
                </li>
            </ul>

        </div>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="card-title"> Data Forum</div>
                    </div>
                    <div class="col">
                    </div>
                    <div class="col">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table responsive-3" id="galeri">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Deskripsi</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-header="No"><?php echo e($no++); ?></td>
                                    <td data-header="Kategori"> <?php echo e($item->name); ?> </td>
                                    <td data-header="Kategori"> <?php echo e($item->email); ?> </td>
                                    <td data-header="Kategori"> <?php echo e($item->subject); ?> </td>
                                    <td data-header="Kategori"> <?php echo e($item->comment); ?> </td>
                                    <td data-header="Kategori"> <a href="/master-admin/forum/publish/<?php echo e($item->id); ?>"
                                            class="<?php echo e($item->publish == 0 ? 'btn btn-primary' : 'btn btn-warning'); ?>">
                                            <?php echo e($item->publish == 0 ? 'Publish' : 'Unpublish'); ?>

                                        </a>

                                    </td>
                                    </a>
                                    <td>
                                        <form action="/master-admin/forum/delete/<?php echo e($item->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm delete-confirm"><i
                                                    class="fa-solid fa-trash" data-toggle="tooltip" data-placement="top"
                                                    title="Hapus"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/datakerja/icommits/laravel/bkpp/resources/views/admin/forum/index.blade.php ENDPATH**/ ?>
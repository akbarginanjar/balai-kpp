<?php

return [
    'zoom_level'           => 10,
    'detail_zoom_level'    => 12,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', '-6.943097'),
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '107.633545'),
];
